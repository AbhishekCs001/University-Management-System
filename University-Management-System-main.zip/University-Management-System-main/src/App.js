import './App.css';
import React from 'react'
import {Eno} from './components'
function App() {
  return (
    <div className="App">
      <Eno/>

    </div>
  );
}

export default App;
