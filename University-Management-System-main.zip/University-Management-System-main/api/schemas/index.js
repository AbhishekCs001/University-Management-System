import main1 from './main1';
import main2 from './main2';
import main3 from './main3';
import main4 from './main4';
import main5 from './main5';

export const schemaTypes = [main1, main2, main3, main4, main5]
