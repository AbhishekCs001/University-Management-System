import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'injni81f',
    dataset: 'production'
  }
})
