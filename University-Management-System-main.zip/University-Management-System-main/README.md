# This is a part of B.Tech 6th Semester Software Engineering Lab 
Link (User): https://software-engineering-ums.netlify.app/
Link (Admin): https://university-admin.sanity.studio/desk

